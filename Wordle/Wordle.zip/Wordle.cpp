#include "WordleBoard.h"
#include <string>

using namespace std;

int main()
{

    // Create the Wordle board
    WordleBoard wordleBoard;

    // Display the empty board
    wordleBoard.UpdateDisplay();

    // Get a new 5-letter word from the user
    string guess = wordleBoard.GetNextGuess();

    // Display a message, e.g., if the word was invalid
    wordleBoard.DisplayMessage("Invalid word");

    // Example: Get a different word from the user, e.g., if
    // one just returned was not a valid word.
    guess = wordleBoard.GetDifferentGuess();

    // Example: Mark the first letter as correct
    wordleBoard.MarkGuessLetterCorrectPosition(0);

    // Example: Mark the third as incorrect
    wordleBoard.MarkGuessLetterWrong(2);

    // Example: Mark the fifth letter as correct but in the wrong position
    wordleBoard.MarkGuessLetterWrongPosition(4);

    // Example: Mark the keyboard letter as correct
    wordleBoard.MarkAlphabetLetterCorrectPosition(guess[0]);

	// Example: Mark the keyboard letter as wrong
    wordleBoard.MarkAlphabetLetterWrong(guess[2]);

	// Example: Mark the keyboard letter as correct but in the wrong position
    wordleBoard.MarkAlphabetLetterWrongPosition(guess[4]);

	// Update the display before continuing
    wordleBoard.UpdateDisplay();

    // Get the next 5-letter word from the user
    guess = wordleBoard.GetNextGuess();

    return EXIT_SUCCESS;
}
